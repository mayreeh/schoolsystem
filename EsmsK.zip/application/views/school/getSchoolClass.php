<?php
echo $q = intval($_GET['q']);

?>
